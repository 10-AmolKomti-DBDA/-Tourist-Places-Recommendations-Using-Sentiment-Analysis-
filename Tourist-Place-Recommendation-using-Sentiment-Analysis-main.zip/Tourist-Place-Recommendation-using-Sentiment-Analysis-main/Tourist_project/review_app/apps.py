from django.apps import AppConfig


class ReviewAppConfig(AppConfig):
    name = 'review_app'

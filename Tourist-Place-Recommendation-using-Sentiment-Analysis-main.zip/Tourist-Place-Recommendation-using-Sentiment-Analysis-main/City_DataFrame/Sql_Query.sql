create database  if not exists city_data;
use city_data;

show tables;

alter table cdf_agra
add id int;

alter table cdf_ahmedabad
add id int;

alter table cdf_delhi
add id int;

alter table cdf_goa
add id int;

alter table cdf_chandigarh
add id int;

alter table cdf_jaipur
add id int;

alter table cdf_kolkata
add id int;

alter table cdf_mumbai
add id int;

alter table cdf_pune
add id int;

alter table cdf_udaipur
add id int;

alter table cdf_varanasi
add id int;

alter table cdf_bangalore
add id int;
